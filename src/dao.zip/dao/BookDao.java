package com.demo.sdjpa.dao;


import com.demo.sdjpa.domain.Book;

public interface BookDao {
    Book getById(Long id);
    Book getByTitle(String title);
    Book saveNewBook(Book book);
    Book updateBook(Book book);
    void deleteBookById(Long id);
}
