package com.demo.sdjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
